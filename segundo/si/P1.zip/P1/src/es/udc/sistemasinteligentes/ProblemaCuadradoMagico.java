package es.udc.sistemasinteligentes;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ProblemaCuadradoMagico extends ProblemaBusqueda {
    private final int n;
    private final int constanteMagica;

    public ProblemaCuadradoMagico(int n) {
        // Invocamos al constructor padre con el estado inicial
        super(crearEstadoInicial(n));
        this.n = n;
        this.constanteMagica = n * (n * n + 1) / 2;
    }

    private static Estado crearEstadoInicial(int n) {
        int[][] tableroInicial = new int[n][n];
        Set<Integer> disponibles = new HashSet<>();
        for (int i = 1; i <= n * n; i++) {
            disponibles.add(i);
        }
        return new EstadoCuadradoMagico(tableroInicial, disponibles);
    }

    @Override
    public boolean esMeta(Estado es) {
        EstadoCuadradoMagico estado = (EstadoCuadradoMagico) es;
        int[][] t = estado.getTablero();

        if (!estado.getNumerosRestantes().isEmpty()) return false;

        for (int i = 0; i < n; i++) {
            int sumaFila = 0;
            int sumaCol = 0;
            for (int j = 0; j < n; j++) {
                sumaFila += t[i][j];
                sumaCol += t[j][i];
            }
            if (sumaFila != constanteMagica || sumaCol != constanteMagica) return false;
        }

        int d1 = 0, d2 = 0;
        for (int i = 0; i < n; i++)
        {
            d1 += t[i][i];
            d2 += t[i][n - 1 - i];
        }

        return d1 == constanteMagica && d2 == constanteMagica;
    }

    @Override
    public Accion[] acciones(Estado es) {
        EstadoCuadradoMagico estado = (EstadoCuadradoMagico) es;
        List<Accion> listaAcciones = new ArrayList<>();

        // Estrategia: Buscar la primera casilla vacía para rellenar
        int filaVacia = -1;
        int colVacia = -1;

        encontrarCasilla:
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (estado.getTablero()[i][j] == 0) {
                    filaVacia = i;
                    colVacia = j;
                    break encontrarCasilla;
                }
            }
        }

        // Si hay una casilla vacía, generamos una acción por cada número disponible
        if (filaVacia != -1) {
            for (Integer valor : estado.getNumerosRestantes()) {
                listaAcciones.add(new AccionColocarNumero(filaVacia, colVacia, valor));
            }
        }

        // Convertimos la lista a Array para cumplir con la firma de la clase abstracta
        return listaAcciones.toArray(new Accion[0]);
    }
}